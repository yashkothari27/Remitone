<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS;

use RemitONE\RemitterWS\classes\Auth;
use RemitONE\RemitterWS\classes\Beneficiary;
use RemitONE\RemitterWS\classes\Rate;
use RemitONE\RemitterWS\classes\RemitterUser;
use RemitONE\RemitterWS\classes\Transaction;
use RemitONE\RemitterWS\classes\UISettings;
use RemitONE\RemitterWS\classes\Wallet;
use RemitONE\RemitterWS\classes\RemitterWSRestClient;

/**
 * Main class for the RemitONE Remitter Web Services
 *
 * This class should be instantiated to perform all requests
 * For example:
 * $remitterWS = new RemitterWS;
 * $remitterWS->auth->methodName();
 */
class RemitterWS {
	
	private $ws = null;
	public $auth = null;
	public $beneficiary = null;
	public $rate = null;
	public $remitterUser = null;
	public $transaction = null;
	public $UISettings = null;
	public $wallet = null;
	
	/**
	 * Instantiate all available requests and a RemitterWSRestClient client
	 *
	 * @return RemitterWS this
	 */
	public function __construct() {
		$this->ws = new RemitterWSRestClient;
		
		$this->auth = new Auth($this->ws);
		$this->beneficiary = new Beneficiary($this->ws);
		$this->rate = new Rate($this->ws);
		$this->remitterUser = new RemitterUser($this->ws);
		$this->transaction = new Transaction($this->ws);
		$this->UISettings = new UISettings($this->ws);
		$this->wallet = new Wallet($this->ws);
	}
	
}