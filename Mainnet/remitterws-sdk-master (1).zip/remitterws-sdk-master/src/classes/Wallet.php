<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Wallet User class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->wallet->methodName();
 */
class Wallet extends RemitterWSBaseClass {
	
	protected $path = 'wallet';
	
	/**
	 * Retrieve the list of wallets and the corresponding balances for the current user
	 *
	 * @return array
	 */
	public function getWallets() {
		$response = $this->ws->request($this->getPath('getWallets'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken()
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of events linked to the remitter wallets
	 *
	 * @param integer $days (optional)
	 * @return array
	 */
	public function getWalletActivity($days=null) {
		$data = [];
		
		if($days!==null) {
			$data['days'] = $days;
		}
		
		$response = $this->ws->request($this->getPath('getWalletActivity'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the charges that will apply to the wallet loading as well as the final amount to pay.
	 * 
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function getLoadWalletCharges($input=[]) {
		$list = [
			'currency',
			'amount',
			'payment_method_id',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('getLoadWalletCharges'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of the wallet loading payment methods available.
	 *
	 * @return array
	 */
	public function getLoadWalletPaymentMethods() {
		$response = $this->ws->request($this->getPath('getLoadWalletPaymentMethods'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken()
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Load the wallet of the remitter.
	 * 
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function loadWallet($input=[]) {
		$list = [
			'currency',
			'amount',
			'payment_method_id',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('loadWallet'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the details of a wallet load
	 *
	 * @param string $my_wallet_ref
	 * @return array
	 */
	public function getLoadWalletDetails($my_wallet_ref) {
		$response = $this->ws->request($this->getPath('getLoadWalletDetails'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'my_wallet_ref' => $my_wallet_ref,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Clears the payment of a wallet load when the Card Processor indicates that the payment was successful
	 *
	 * @param string $my_wallet_ref
	 * @return array
	 */
	public function loadWalletPaymentCleared($my_wallet_ref) {
		// We will need the details of the wallet transaction to generate the security hash
		$walletTransaction = $this->getLoadWalletDetails($my_wallet_ref);
		
		$response = $this->ws->request($this->getPath('loadWalletPaymentCleared'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'my_wallet_ref' => $my_wallet_ref,
			'security_hash' => $this->generateSecurityHash($walletTransaction),
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the rate used in the conversion and calculate the final amount that will be moved between two of the remitter's wallets.
	 * 
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function calculateMoveFundsBetweenWallets($input=[]) {
		$list = [
			'from_currency',
			'to_currency',
			'amount',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('calculateMoveFundsBetweenWallets'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Move funds between two of the remitter's wallets.
	 * 
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function moveFundsBetweenWallets($input=[]) {
		$list = [
			'from_currency',
			'to_currency',
			'amount',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('moveFundsBetweenWallets'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Generate the Security Hash for a given transaction
	 * 
	 * @param array $walletTransaction
	 * @return string
	 */
	private function generateSecurityHash(array $walletTransaction) {
		$config = $this->ws->config->getLoadWalletPaymentClearRecipe();
		
		if(!$config || empty($config['secret_key'])) {
			throw new RemitterWSException('Please set up your wallet security hash recipe');
		}
		else if(empty($walletTransaction)) {
			return null;
		}
		
		// Gather the elements
		$text = '';
		
		foreach($config['elements'] as $element) {
			switch($element) {
				case 'my_wallet_ref':
					$text .= substr($walletTransaction['my_wallet_ref'], $config['my_wallet_ref_offset'], $config['my_wallet_ref_length']);
					break;
				case 'secret_key':
					$text .= $config['secret_key'];
					break;
				default:
					// This should come from the wallet transaction model directly
					$text .= $walletTransaction[$element];
					break;
			}
		}
		
		// Hash the text with the configured function and keep the X last characters
		$text = hash($config['hash_function'], $text);
		
		return substr($text, -1*$config['length']);
	}
	
}