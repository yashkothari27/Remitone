<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSResponse;

/**
 * Exception for the RemitONE Remitter Web Services
 */
class RemitterWSException extends \Exception {
	
	protected $_type;
	protected $_data;
	protected $_response;
	
	/**
	 * Instantiate a new RemitterWS Exception
	 * 
	 * @param string $message
	 * @param string $type
	 * @param any $data
	 * @param RemitterWSResponse $response
	 */
	public function __construct($message, $type=null, $data=null, RemitterWSResponse $response=null) {
		parent::__construct($message);
		
		$this->_type = $type;
		$this->_data = $data;
		$this->_response = $response;
	}
	
	public function getType() {
		return $this->_type?:'GENERAL';
	}
	
	public function getData() {
		return $this->_data;
	}
	
	public function getResponse() {
		return $this->_response;
	}
	
}