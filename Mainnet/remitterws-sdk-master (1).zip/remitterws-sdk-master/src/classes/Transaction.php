<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Transaction class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->transaction->methodName();
 */
class Transaction extends RemitterWSBaseClass {
	
	protected $path = 'transaction';
	
	/**
	 * Retrieve the list of Mobile Network Operators for a given destination country
	 * 
	 * @param integer $destination_country_id
	 * @return array
	 */
	public function getMobileNetworkOperators($destination_country_id) {
		$response = $this->ws->request($this->getPath('getMobileNetworkOperators'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Mobile Network Credit types
	 * 
	 * @param integer $mobile_network_operator_id
	 * @return array
	 */
	public function getMobileNetworkCreditTypes($mobile_network_operator_id) {
		$response = $this->ws->request($this->getPath('getMobileNetworkCreditTypes'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'mobile_network_operator_id' => $mobile_network_operator_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Utility Bill Companies for a given destination country
	 * 
	 * @param integer $destination_country_id
	 * @return array
	 */
	public function getUtilityBillCompanies($destination_country_id) {
		$response = $this->ws->request($this->getPath('getUtilityBillCompanies'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Search for Utility Bill Companies for a given destination country and a search term
	 * 
	 * @param integer $destination_country_id
	 * @param string $search
	 * @return array
	 */
	public function searchUtilityBillCompanies($destination_country_id, $search) {
		$response = $this->ws->request($this->getPath('searchUtilityBillCompanies'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
			'search' => $search,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Delivery Banks for a given destination country
	 * 
	 * @param integer $destination_country_id
	 * @return array
	 */
	public function getDeliveryBanks($destination_country_id) {
		$response = $this->ws->request($this->getPath('getDeliveryBanks'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Delivery Branch States for a given delivery bank
	 * 
	 * @param integer $delivery_bank_id
	 * @return array
	 */
	public function getDeliveryBranchStates($delivery_bank_id) {
		$response = $this->ws->request($this->getPath('getDeliveryBranchStates'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'delivery_bank_id' => $delivery_bank_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Delivery Branch Cities for a given delivery bank (and branch state?)
	 * 
	 * @param integer $delivery_bank_id
	 * @param string $delivery_branch_state (optional)
	 * @return array
	 */
	public function getDeliveryBranchCities($delivery_bank_id, $delivery_branch_state=null) {
		$data = [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'delivery_bank_id' => $delivery_bank_id,
		];
		
		if($delivery_branch_state!==null) {
			$data['delivery_branch_state'] = $delivery_branch_state;
		}
		
		$response = $this->ws->request($this->getPath('getDeliveryBranchCities'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Delivery Branches for a given delivery bank (and branch state/city?)
	 * 
	 * @param integer $delivery_bank_id
	 * @param string $delivery_branch_state (optional)
	 * @param string $delivery_branch_city (optional)
	 * @return array
	 */
	public function getDeliveryBranches($delivery_bank_id, $delivery_branch_state=null, $delivery_branch_city=null) {
		$data = [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'delivery_bank_id' => $delivery_bank_id,
		];
		
		if($delivery_branch_state!==null) {
			$data['delivery_branch_state'] = $delivery_branch_state;
		}
		
		if($delivery_branch_city!==null) {
			$data['delivery_branch_city'] = $delivery_branch_city;
		}
		
		$response = $this->ws->request($this->getPath('getDeliveryBranches'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Collection Point States for a given destination country
	 * 
	 * @param integer $destination_country_id
	 * @return array
	 */
	public function getCollectionPointStates($destination_country_id) {
		$response = $this->ws->request($this->getPath('getCollectionPointStates'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Collection Point Cities for a given destination country and state
	 * 
	 * @param integer $destination_country_id
	 * @param string $collection_point_state
	 * @return array
	 */
	public function getCollectionPointCities($destination_country_id, $collection_point_state=null) {
		$response = $this->ws->request($this->getPath('getCollectionPointCities'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
			'collection_point_state' => $collection_point_state,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of Delivery Branches for a given destination country (and collection point state/city?)
	 * 
	 * @param integer $destination_country_id
	 * @param string $collection_point_state (optional)
	 * @param string $collection_point_city (optional)
	 * @return array
	 */
	public function getCollectionPoints($destination_country_id, $collection_point_state=null, $collection_point_city=null) {
		$data = [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		];
		
		if($collection_point_state!==null) {
			$data['collection_point_state'] = $collection_point_state;
		}
		
		if($collection_point_city!==null) {
			$data['collection_point_city'] = $collection_point_city;
		}
		
		$response = $this->ws->request($this->getPath('getCollectionPoints'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the charges for a particular transaction setup
	 *
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function getCharges($input) {
		$list = [
			'destination_country',
			'trans_type',
			'payment_method',
			'service_level',
			'sms_confirmation',
			'sms_notification',
			'sms_benef_confirmation',
			'amount_type',
			'amount_to_send',
			'source_currency',
			'destination_currency',
			'collection_point_id',
			'benef_branch_id',
			'benef_bank',
			'benef_mobiletransfer_network_credit_type_id',
			'utility_company',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('getCharges'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Create a new Transaction
	 *
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function createTransaction($input=[]) {
		$list = [
			'trans_type',
			'beneficiary_id',
			'account_item_number',
			'source_currency',
			'destination_currency',
			'amount_type',
			'amount',
			'purpose',
			'source_of_income',
			'payment_method',
			'payment_token',
			'remitter_wallet_currency',
			'service_level',
			'discount_code',
			'sms_confirmation',
			'sms_notification',
			'sms_mobile',
			'sms_benef_confirmation',
			'sms_benef_mobile',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('createTransaction'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Confirm a newly created Transaction
	 *
	 * @param array $input All input data with the correct keys (optional)
	 * @return array
	 */
	public function confirmTransaction($input=[]) {
		$list = [
			'trans_session_id',
			'email_confirmation_code',
			'sms_confirmation_code',
			'confirmation_pin',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('confirmTransaction'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Request a new Transaction Confirmation Code (when possible)
	 *
	 * @param array $trans_session_id The temporary Transaction ID (before confirmation)
	 * @return array
	 */
	public function requestTransactionConfirmationCode($trans_session_id) {
		$response = $this->ws->request($this->getPath('requestTransactionConfirmationCode'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'trans_session_id' => $trans_session_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Marks transactions in PENDING_CLEARANCE status as payment cleared.
	 *
	 * @param string $trans_ref
	 * @param string $payment_token (optional)
	 * @return array
	 */
	public function paymentCleared($trans_ref, $payment_token=null) {
		// We will need the details of the transaction to generate the security hash
		$transaction = $this->getTransaction($trans_ref)['transaction'][0];
		
		$data = [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'trans_ref' => $trans_ref,
			'security_hash' => $this->generateSecurityHash($transaction),
		];
		
		if($payment_token!==null) {
			$data['payment_token'] = $payment_token;
		}
		
		$response = $this->ws->request($this->getPath('paymentCleared'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * List the transactions for the current remitter
	 *
	 * @param array $input All input data with the correct keys (optional)
	 * @return array
	 */
	public function listTransactions($input=[]) {
		$list = [
			'from_date',
			'to_date',
			'trans_type',
			'status',
			'destination_country',
			'source_currency',
			'destination_currency',
			'beneficiary_id',
			'payment_method',
			'remitter_wallet_currency',
			'order',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('listTransactions'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the details of an existing Transaction
	 *
	 * @param string $trans_ref The transaction reference of the transaction
	 * @return array
	 */
	public function getTransaction($trans_ref) {
		$response = $this->ws->request($this->getPath('getTransaction'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'trans_ref' => $trans_ref,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the payment instructions for a Transaction
	 *
	 * @param string $trans_ref The transaction reference of the transaction
	 * @return array
	 */
	public function getTransactionPaymentInstructions($trans_ref) {
		$response = $this->ws->request($this->getPath('getTransactionPaymentInstructions'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'trans_ref' => $trans_ref,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Generate the Security Hash for a given transaction
	 * 
	 * @param array $transaction
	 * @return string
	 */
	private function generateSecurityHash(array $transaction) {
		$config = $this->ws->config->getPaymentClearRecipe();
		
		if(!$config || empty($config['secret_key'])) {
			throw new RemitterWSException('Please set up your transaction security hash recipe');
		}
		else if(empty($transaction)) {
			return null;
		}
		
		// Gather the elements
		$text = '';
		
		foreach($config['elements'] as $element) {
			switch($element) {
				case 'trans_ref':
					$text .= substr($transaction['trans_ref'], $config['trans_ref_offset'], $config['trans_ref_length']);
					break;
				case 'secret_key':
					$text .= $config['secret_key'];
					break;
				default:
					// This should come from the transaction model directly
					$text .= $transaction[$element];
					break;
			}
		}
		
		// Hash the text with the configured function and keep the X last characters
		$text = hash($config['hash_function'], $text);
		
		return substr($text, -1*$config['length']);
	}
	
}