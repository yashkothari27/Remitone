<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Beneficiary class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->beneficiary->methodName();
 */
class Beneficiary extends RemitterWSBaseClass {
	
	protected $path = 'beneficiary';
	
	/**
	 * List all destination countries
	 *
	 * @return array
	 */
	public function getDestinationCountries() {
		$response = $this->ws->request($this->getPath('getDestinationCountries'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Create a new Beneficiary
	 *
	 * @param array $input All input data with the correct keys (optional)
	 * @return array
	 */
	public function createBeneficiary($input=[]) {
		$list = $this->getBeneficiaryParameters();
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('createBeneficiary'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Update an existing Beneficiary
	 *
	 * @param array $input All input data with the correct keys (optional)
	 * @return array
	 */
	public function updateBeneficiary($input=[]) {
		$list = array_merge(['beneficiary_id'], $this->getBeneficiaryParameters());
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('updateBeneficiary'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * List all existing Beneficiaries
	 *
	 * @param integer $destination_country_id The destination country ID (optional)
	 * @return array
	 */
	public function listBeneficiaries($destination_country_id=null) {
		$data = [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
		];
		
		if($destination_country_id!=null) {
			$data['destination_country_id'] = $destination_country_id;
		}
		
		$response = $this->ws->request($this->getPath('listBeneficiaries'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * Get a specific Beneficiary
	 *
	 * @param integer $beneficiary_id The id of the beneficiary
	 * @return array
	 */
	public function getBeneficiary($beneficiary_id) {
		$response = $this->ws->request($this->getPath('getBeneficiary'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'beneficiary_id' => $beneficiary_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Internal method to return the list of all Beneficiary parameters shared between creation and update
	 * 
	 * @return array
	 */
	private function getBeneficiaryParameters() {
		return [
			'fname',
			'lname',
			'nickname',
			'gender',
			'address1',
			'address2',
			'address3',
			'city',
			'state',
			'postcode',
			'country_id',
			'nationality',
			'dob',
			'email',
			'telephone',
			'mobile',
			'sms_payout_mobile',
			'avatar',
			'import_id',
			'id_type',
			'id_details',
			'id_start',
			'id_expiry',
			'id_scan',
			'id_issued_by',
			'id_issue_place',
			'id_issue_country',
			'card_number',
			'bank_account_number1',
			'bank_account_type1',
			'bank_account_name1',
			'bank1',
			'bank_iban1',
			'bank_swift_code1',
			'bank_ifsc_code1',
			'bank_bsb_code1',
			'bank_branch1',
			'bank_branch_id1',
			'bank_branch_code1',
			'bank_branch_city1',
			'bank_branch_state1',
			'bank_branch_postcode1',
			'bank_branch_telephone1',
			'bank_branch_manager1',
			'additional_bank1',
			'additional_bank_branch1',
			'intermediary_bank_account_number1',
			'intermediary_bank1',
			'intermediary_bank_address1',
			'intermediary_bank_swift_code1',
			'bank_account_number2',
			'bank_account_type2',
			'bank_account_name2',
			'bank2',
			'bank_iban2',
			'bank_swift_code2',
			'bank_ifsc_code2',
			'bank_bsb_code2',
			'bank_branch2',
			'bank_branch_id2',
			'bank_branch_code2',
			'bank_branch_city2',
			'bank_branch_state2',
			'bank_branch_postcode2',
			'bank_branch_telephone2',
			'bank_branch_manager2',
			'intermediary_bank_account_number2',
			'intermediary_bank2',
			'intermediary_bank_address2',
			'intermediary_bank_swift_code2',
			'bank_account_number3',
			'bank_account_type3',
			'bank_account_name3',
			'bank3',
			'bank_iban3',
			'bank_swift_code3',
			'bank_ifsc_code3',
			'bank_bsb_code3',
			'bank_branch3',
			'bank_branch_id3',
			'bank_branch_code3',
			'bank_branch_city3',
			'bank_branch_state3',
			'bank_branch_postcode3',
			'bank_branch_telephone3',
			'bank_branch_manager3',
			'intermediary_bank_account_number3',
			'intermediary_bank3',
			'intermediary_bank_address3',
			'intermediary_bank_swift_code3',
			'bank_account_number4',
			'bank_account_type4',
			'bank_account_name4',
			'bank4',
			'bank_iban4',
			'bank_swift_code4',
			'bank_ifsc_code4',
			'bank_bsb_code4',
			'bank_branch4',
			'bank_branch_id4',
			'bank_branch_code4',
			'bank_branch_city4',
			'bank_branch_state4',
			'bank_branch_postcode4',
			'bank_branch_telephone4',
			'bank_branch_manager4',
			'intermediary_bank_account_number4',
			'intermediary_bank4',
			'intermediary_bank_address4',
			'intermediary_bank_swift_code4',
			'collection_point_id',
			'collection_point_name',
			'collection_point_code',
			'collection_point_proc_bank',
			'collection_point_address',
			'collection_point_city',
			'collection_point_state',
			'collection_point_tel',
			'utility_bill_company',
			'utility_bill_company_code',
			'utility_bill_address1',
			'utility_bill_address2',
			'utility_bill_address3',
			'utility_bill_city',
			'utility_bill_state',
			'utility_bill_postcode',
			'utility_bill_bank',
			'utility_bill_account_no',
			'utility_bill_bank_bic',
			'utility_bill_bank_swift_iban',
			'mobile_transfer_number',
			'mobile_transfer_network',
			'mobile_transfer_network_id',
			'mobile_transfer_network_credit_type_id',
			'mobile_transfer_network_credit_type',
			'card_number',
			'home_delivery_notes',
		];
	}
	
}