<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSConfig;
use RemitONE\RemitterWS\classes\RemitterWSException;
use RemitONE\RemitterWS\classes\RemitterWSResponse;
use RemitONE\RemitterWS\classes\RemitterWSLogger;

/**
 * REST client to query the RemitONE Remitter Web Services
 */
class RemitterWSRestClient {
	
	public $config = null;
	private $logger = null;
	
	/**
	 * Instantiate a RemitterWSConfig configuration holder
	 *
	 * @return RemitterWSRestClient this
	 */
	public function __construct() {
		$this->config = new RemitterWSConfig;
		$this->logger = RemitterWSLogger::getLogger();
	}
	
	/**
	 * Perform a request to the RemitONE Remitter Web Services with the supplied arguments
	 *
	 * @param string $path The path of the method to query
	 * @param array $data The parameters of the request
	 * @throws RemitterWSException If any wrong happens during the request
	 */
	public function request($path, array $data=[]) {
		$url = $this->config->getUrl();
		
		if(!$url || $url=='http://company.com') {
			throw new RemitterWSException('Please set up your RemitONE application url');
		}
		else {
			// Construct the complete path
			rtrim('/', $url);
			$url .= '/'.$path;
		}
		
		
		// Open connection
		$curl = curl_init();

		// Set up cURL options
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_POST, count($data));
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		
		// Allow access to HTTPS
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($curl, CURLOPT_TIMEOUT, 60);
		
		$result = curl_exec($curl);
		
		$curl_errno = curl_errno($curl);
		$curl_error = curl_error($curl);
		$httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		
		curl_close($curl);
		
		
		if($this->config->isVerbose()) {
			$this->logger->addInfo("Request to {$url} with the following POST data:".PHP_EOL.json_encode($data, JSON_PRETTY_PRINT));
			$this->logger->addInfo("Response:".PHP_EOL.$result);
		}
		
		
		if ($curl_errno > 0) {
			throw new RemitterWSException("cURL error ($curl_errno): $curl_error", 510);
		}
		
		if ($httpCode == 403) {
			throw new RemitterWSException('Forbidden access', 403);
		}
		
		if ($httpCode == 404) {
			throw new RemitterWSException('Unable to access remote system', 404);
		}
		
		if ($httpCode == 302) {
			throw new RemitterWSException('The document has moved', 302);
		}
		
		
		// Try to cast the result as an object
		try {
			$result = simplexml_load_string($result, 'SimpleXMLElement', LIBXML_NOCDATA);
		}
		catch(\Exception $e) {
			throw new RemitterWSException('Incorrect data retrieved. Please contact RemitONE');
		}
		
		return new RemitterWSResponse($result);
	}
	
	/**
	 * Encrypt the supplied argument using the remove server public key
	 *
	 * @param array $data The data to encrypt
	 * @throws RemitterWSException If any wrong happens during the encryption
	 */
	public function encrypt($data) {
		$path = $this->config->getServerPublicKeyPath();
		
		if(!file_exists($path)) {
			throw new RemitterWSException('Please set up the RemitONE server public key');
		}
		
		$key = file_get_contents($path);
		$key = openssl_get_publickey($key);
		
		if(!$key) {
			throw new RemitterWSException('Unable to use RemitONE server public key');
		}
		
		openssl_public_encrypt(json_encode($data), $crypted , $key);
		
		if($crypted===null) {
			throw new RemitterWSException('Unable to use RemitONE server public key');
		}
		return base64_encode($crypted);
	}
	
	/**
	 * Decrypt the supplied argument using the app private key
	 *
	 * @param array $data The data to decrypt
	 * @throws RemitterWSException If any wrong happens during the decryption
	 */
	public function decrypt($data) {
		$path = $this->config->getAppPrivateKeyPath();
		
		if(!file_exists($path)) {
			throw new RemitterWSException('Please set up the App private key');
		}
		
		$key = file_get_contents($path);
		$key = openssl_get_privatekey($key);
		
		if(!$key) {
			throw new RemitterWSException('Unable to use the App private key');
		}
		
		openssl_private_decrypt(base64_decode($data), $decrypted , $key);
		
		if($decrypted===null) {
			throw new RemitterWSException('Unable to use the App private key');
		}
		
		return json_decode($decrypted, true);
	}
	
}
