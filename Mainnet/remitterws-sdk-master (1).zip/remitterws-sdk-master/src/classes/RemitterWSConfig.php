<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\Configuration;

/**
 * Configuration class to hold RemitterWSRestClient settings
 */
class RemitterWSConfig {
	
	private $_username = null;
	private $_token = null;
	private $_seed = null;
	
	private $_url = null;
	private $_app_private_key_path = null;
	private $_server_public_key_path = null;
	private $_payment_clear_recipe = null;
	private $_load_wallet_payment_clear_recipe = null;
	private $_verbose = false;
	
	/**
	 * Load the configuration file
	 *
	 * @return RemitterWSConfig this
	 */
	public function __construct() {
		$config = new Configuration;
		
		$this->_url = $config->url;
		$this->_app_private_key_path = $config->app_private_key_path;
		$this->_server_public_key_path = $config->server_public_key_path;
		$this->_payment_clear_recipe = $config->security_hash;
		$this->_load_wallet_payment_clear_recipe = $config->wallet_security_hash;
		$this->_verbose = $config->verbose;
	}
	
	/**
	 * Return the username of the current user
	 *
	 * @return string|null Username
	 */
	public function getUsername() {
		return $this->_username;
	}
	
	/**
	 * Set the username of the current user
	 *
	 * @param string $username The username of the current user
	 * @throws RemitterWSException If the username is not a string or is not null
	 */
	public function setUsername($username) {
		if(!is_string($username) && $username!==null) {
			throw new RemitterWSException('The username can only be set to null or a string');
		}
		
		$this->_username = $username;
	}
	
	/**
	 * Return the session token of the current user
	 *
	 * @return string|null Session Token
	 */
	public function getToken() {
		return $this->_token;
	}
	
	/**
	 * Set the session token of the current user
	 *
	 * @param string $token The session token of the current user
	 * @throws RemitterWSException If the session token is not a string or is not null
	 */
	public function setToken($token) {
		if(!is_string($token) && $token!==null) {
			throw new RemitterWSException('The session token can only be set to null or a string');
		}
		
		$this->_token = $token;
	}
	
	/**
	 * Return the seed for the current user
	 *
	 * @return string|null Seed
	 */
	public function getSeed() {
		return $this->_seed;
	}
	
	/**
	 * Set the seed for the current user
	 *
	 * @param string $seed The seed for the current user
	 * @throws RemitterWSException If the seed is not a string or is not null
	 */
	public function setSeed($seed) {
		if(!is_string($seed) && $seed!==null) {
			throw new RemitterWSException('The seed can only be set to null or a string');
		}
		
		$this->_seed = $seed;
	}
	
	/**
	 * Return the url of the RemitONE application
	 *
	 * @return string|null Url
	 */
	public function getUrl() {
		return $this->_url;
	}
	
	/**
	 * Return the path of the app private key
	 *
	 * @return string|null Path of the app private key
	 */
	public function getAppPrivateKeyPath() {
		return $this->_app_private_key_path;
	}
	
	/**
	 * Return the path of the server public key
	 *
	 * @return string|null Path of the server public key
	 */
	public function getServerPublicKeyPath() {
		return $this->_server_public_key_path;
	}
	
	/**
	 * Return the recipe for clearing the payment of a transaction
	 *
	 * @return array Recipe
	 */
	public function getPaymentClearRecipe() {
		return (array) $this->_payment_clear_recipe;
	}
	
	/**
	 * Return the recipe for clearing the payment of a wallet load
	 *
	 * @return array Recipe
	 */
	public function getLoadWalletPaymentClearRecipe() {
		return (array) $this->_load_wallet_payment_clear_recipe;
	}
	
	/**
	 * Indicate if the SDK should be verbose
	 *
	 * @return boolean
	 */
	public function isVerbose() {
		return (boolean) $this->_verbose;
	}
	
}