<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Remitter User class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->remitterUser->methodName();
 */
class RemitterUser extends RemitterWSBaseClass {
	
	protected $path = 'remitterUser';
	
	/**
	 * Get the profile of the Remitter User
	 *
	 * @return array
	 */
	public function getProfile() {
        $response = $this->ws->request($this->getPath('getProfile'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken()
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Update the profile of the current Remitter User
	 *
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function updateProfile($input) {
		$list = [
			'nationality',
			'gender',
			'building_no',
			'address1',
			'address2',
			'city',
			'state',
			'postcode',
			'email',
			'telephone',
			'mobile',
			'fax',
			'dob',
			'place_of_birth',
			'country_of_birth',
			'avatar',
			'id1_type',
			'id1_details',
			'id1_issued_by',
			'id1_issue_place',
			'id1_start',
			'id1_expiry',
			'id1_scan1',
			'id1_scan2',
			'id1_scan3',
			'id2_type',
			'id2_details',
			'id2_issue_by',
			'id2_issue_place',
			'id2_start',
			'id2_expiry',
			'id2_scan1',
			'id2_scan2',
			'id2_scan3',
			'id3_type',
			'id3_details',
			'id3_issue_by',
			'id3_issue_place',
			'id3_start',
			'id3_expiry',
			'id3_scan1',
			'id3_scan2',
			'id3_scan3',
			'id4_type',
			'id4_details',
			'id4_issue_by',
			'id4_issue_place',
			'id4_start',
			'id4_expiry',
			'id4_scan1',
			'id4_scan2',
			'id4_scan3',
			'taxpayer_reg',
			'account_number',
			'sort_code',
			'remitter_username',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('updateProfile'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of all source countries available for registration
	 *
	 * @return array
	 */
	public function getSourceCountries() {
		$response = $this->ws->request($this->getPath('getSourceCountries'));
		
		return $response->getResult();
	}
	
	/**
	 * Register a new Remitter User
	 *
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function register($input) {
		$list = [
			'fname',
			'lname',
			'nationality',
			'gender',
			'building_no',
			'address1',
			'address2',
			'city',
			'state',
			'source_country_id',
			'postcode',
			'email',
			'password',
			'telephone',
			'mobile',
			'fax',
			'dob',
			'place_of_birth',
			'country_of_birth',
			'avatar',
			'id1_type',
			'id1_details',
			'id1_issued_by',
			'id1_issue_place',
			'id1_start',
			'id1_expiry',
			'id1_scan',
			'id2_type',
			'id2_details',
			'id2_issue_by',
			'id2_issue_place',
			'id2_start',
			'id2_expiry',
			'id2_scan',
			'taxpayer_reg',
			'account_number',
			'sort_code',
			'hear_about_us',
			'toc',
		];
		
		$data = $this->getRequestData($list, $input);
		
		// Prepare the passwor for encryption
		$password = null;
		
		if(isset($input['password'])) {
			$password = $input['password'];
			unset($data['password']);
		}
		
		
		$response = $this->ws->request($this->getPath('register'), array_merge([
				'encrypted_data' => $this->ws->encrypt([
					'password' => $password,
				]),
			], $data));
		
		return $response->getResult();
	}
	
	/**
	 * Confirm the registration of a new Remitter User
	 *
	 * @param array $input All input data with the correct keys
	 * @return array
	 */
	public function confirmRegistration($input) {
		$list = [
			'email_address',
			'email_verification_code',
			'sms_verification_code',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('confirmRegistration'), $data);
		
		return $response->getResult();
	}
	
	/**
	 * Request a new Registration Confirmation Code
	 *
	 * @param string $email_address The email address used during registration
	 * @return array
	 */
	public function requestRegistrationConfirmationCode($email_address) {
		$response = $this->ws->request($this->getPath('requestRegistrationConfirmationCode'), [
			'email_address' => $email_address
		]);
		
		$status = $response->getStatus();
		return ($status=='SUCCESS');
	}
	
	/**
	 * Requests the base64 of the KYC Video.
     *
	 * @throws Exception
	 */
	public function getProfileKYCVideo() {
		$response = $this->ws->request($this->getPath('getProfileKYCVideo'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken()
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Uploads the profile KYC Video in base64.
     *
	 * @throws Exception
	 */
	public function uploadProfileKYCVideo($input) {
		$response = $this->ws->request($this->getPath('uploadProfileKYCVideo'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'kyc_video' => $input['kyc_video'],
			'filename' => $input['filename'],
		]);
		
		return $response->getResult();		
	}
}