<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Authentication class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->auth->methodName();
 */
class Auth extends RemitterWSBaseClass {
	
	protected $path = 'auth';
	
	/**
	 * Retrieve a seed from the remote server in order to login
	 *
	 * @return string Seed
	 */
	protected function getSeed() {
		$response = $this->ws->request($this->getPath('getSeed'), [
			'username' => $this->ws->config->getUsername(),
		]);
		
		$seed = $response->getResult()['seed'];
		
		$this->ws->config->setSeed($seed);
		return $seed;
	}
	
	/**
	 * Attempt to create a new session on the remote server
	 *
	 * @param string $password The password of the user (will be encrypted)
	 * @return RemitterWSResponse Result
	 */
	public function login($password) {
		$this->getSeed();
		
		$response = $this->ws->request($this->getPath('login'), [
			'username' => $this->ws->config->getUsername(),
			'encrypted_data' => $this->ws->encrypt([
				'seed' => $this->ws->config->getSeed(),
				'password' => $password,
			]),
		]);
		
		$token = $response->getResult()['session_token'];
		
		$this->ws->config->setToken($token);
		return $response->getResult();
	}
	
	/**
	 * Attempt to create a new session on the remote server
	 *
	 * @param string $pin The pin of the user (will be encrypted)
	 * @return RemitterWSResponse Result
	 */
	public function loginPin($pin) {
		$this->getSeed();
		
		$response = $this->ws->request($this->getPath('loginPin'), [
			'username' => $this->ws->config->getUsername(),
			'encrypted_data' => $this->ws->encrypt([
				'seed' => $this->ws->config->getSeed(),
				'pin' => $pin,
			]),
		]);
		
		$token = $response->getResult()['session_token'];
		
		$this->ws->config->setToken($token);
		return $response->getResult();
	}
	
	/**
	 * Confirm the Two Factor Authentication for login
	 * 
	 * @param string $code
	 * @return array
	 */
	public function confirmTwoFactorAuthentication($code) {
		$response = $this->ws->request($this->getPath('confirmTwoFactorAuthentication'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'code' => $code,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Request a new Two Factor Authentication code
	 * 
	 * @return array
	 */
	public function requestTwoFactorAuthentication() {
		$response = $this->ws->request($this->getPath('requestTwoFactorAuthentication'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Log out the user
	 * 
	 * @return boolean Result
	 */
	public function logout() {
		$response = $this->ws->request($this->getPath('logout'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
		]);
		
		$status = $response->getStatus();
		return ($status=='SUCCESS');
	}
	
	/**
	 * Initiate the forgot password procedure for the remitter
	 *
	 * @param string $dob The date of birth of the remitter (YYYY-MM-DD)
	 * @return boolean Result
	 */
	public function forgotPassword($dob) {
		$response = $this->ws->request($this->getPath('forgotPassword'), [
			'username' => $this->ws->config->getUsername(),
			'dob' => $dob,
		]);
		
		$status = $response->getStatus();
		return ($status=='SUCCESS');
	}
	
	/**
	 * Attempt to change the password of the user
	 *
	 * @param string $newPassword The new password of the user (will be encrypted)
	 * @param string $forgotPasswordToken The token received by the user when not logged in
	 * @return boolean|array Result
	 */
	public function changePassword($newPassword, $forgotPasswordToken=null) {
		$this->getSeed();
		
		$data = [
			'username' => $this->ws->config->getUsername(),
			'encrypted_data' => $this->ws->encrypt([
				'seed' => $this->ws->config->getSeed(),
				'new_password' => $newPassword,
			]),
		];
		
		// The user may or may not be logged in
		// The required fields will be different depending on the situation
		if($this->ws->config->getToken()!==null) {
			$data['session_token'] = $this->ws->config->getToken();
		}
		else {
			$data['forgot_password_token'] = $forgotPasswordToken;
		}
		
		$response = $this->ws->request($this->getPath('changePassword'), $data);
		
		if(isset($data['session_token'])) {
			// The user was already logged in and will just get a confirmation
			$status = $response->getStatus();
			return ($status=='SUCCESS');
		}
		else {
			// The user was not logged in. But he is now!
			return $response->getResult();
		}
	}
	
	/**
	 * Attempt to change the pin of the user
	 * 
	 * @param string $newPin
	 * @param string|null $currentPin
	 * @param string|null $currentPassword
	 * @return boolean Result
	 */
	public function changePin($newPin, $currentPin=null, $currentPassword=null) {
		$this->getSeed();
		
		$encryptedData = [
			'seed' => $this->ws->config->getSeed(),
			'pin' => $newPin,
		];
		
		if($currentPin!==null) {
			$encryptedData['current_pin'] = $currentPin;
		}
		elseif($currentPassword!==null) {
			$encryptedData['current_password'] = $currentPassword;
		}
		
		$response = $this->ws->request($this->getPath('changePin'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'encrypted_data' => $this->ws->encrypt($encryptedData),
		]);
		
		$status = $response->getStatus();
		return ($status=='SUCCESS');
	}
	
	/**
	 * Return the username of the current user
	 *
	 * @return string|null Username
	 */
	public function getUsername() {
		return $this->ws->config->getUsername();
	}
	
	/**
	 * Set the username of the current user
	 *
	 * @param string $username The username of the current user
	 * @throws RemitterWSException If the username is not a string or is not null
	 */
	public function setUsername($username) {
		if(!is_string($username) && $username!==null) {
			throw new RemitterWSException('The username can only be set to null or a string');
		}
		
		$this->ws->config->setUsername($username);
	}
	
	/**
	 * Return the session token of the current user
	 *
	 * @return string|null Session Token
	 */
	public function getToken() {
		return $this->ws->config->getToken();
	}
	
	/**
	 * Set the session token of the current user
	 *
	 * @param string $username The session token of the current user
	 * @throws RemitterWSException If the session token is not a string or is not null
	 */
	public function setSessionToken($token) {
		if(!is_string($token) && $token!==null) {
			throw new RemitterWSException('The session token can only be set to null or a string');
		}
		
		$this->ws->config->setToken($token);
	}
	
}