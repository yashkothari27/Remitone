<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use Monolog\Logger;
use Monolog\Handler\ErrorLogHandler;
use Monolog\Formatter\LineFormatter;

/**
 * Logger for the RemitONE Remitter Web Services
 */
class RemitterWSLogger {
	
	private static $logger = null;
	
	public static function getLogger() {
		if(self::$logger===null) {
			self::setLogger();
		}
		
		return self::$logger;
	}
	
	private static function setLogger() {
		$logger = new Logger("log");
		$handler = new ErrorLogHandler();
		$formatter = new LineFormatter("[%datetime%] %channel%.%level_name%: %message%\n", null, true);
		
		$handler->setFormatter($formatter);
		$logger->pushHandler($handler);
		
		self::$logger = $logger;
	}
	
}