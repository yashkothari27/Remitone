<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Response body for the RemitONE Remitter Web Services
 */
class RemitterWSResponse {
	
	private $_response;
	private $_responseId;
	private $_responseCode;
	private $_status;
	private $_resultArray;
	
	/**
	 * Instantiate a new RemitterWS response object
	 *
	 * @param object $simpleXMLElement
	 * @throws RemitterWSException
	 * @return RemitterWSResponse this
	 */
	public function __construct($simpleXMLElement) {
		$this->_response = $simpleXMLElement;
		
		if(isset($simpleXMLElement->responseId)) {
			$this->_responseId = (int) $simpleXMLElement->responseId;
		}
		
		if(isset($simpleXMLElement->response_code)) {
			$this->_responseCode = (string) $simpleXMLElement->response_code;
		}
		
		if(isset($simpleXMLElement->status)) {
			$this->_status = (string) $simpleXMLElement->status;
		}
		
		if(isset($simpleXMLElement->result)) {
			// Keep an array version of the result for easy access
			// The SimpleXMLElement version is still available as part of the getResponse() method
			$this->_resultArray = $this->convertResultAsArray($simpleXMLElement->result);
			$this->_resultArray = json_decode( json_encode($this->_resultArray) , 1);
		}
		
		
		// If there are any issue, deal with it
		if($this->getStatus()=='FAIL') {
			$message = null;
			$type = null;
			$data = null;
			
			if($simpleXMLElement->message=='VALIDATION FAILED') {
				$message = 'Validation Failed';
				$type = 'VALIDATION';
				$data = $this->getResult()['errors'];
			}
			elseif($simpleXMLElement->message=='Compliance check(s) failed') {
				$message = $simpleXMLElement->message;
				$type = 'COMPLIANCE';
				$data = $this->getResult()['errors'];
			}
			else {
				$message = $simpleXMLElement->message;
			}
			
			throw new RemitterWSException($message, $type, $data, $this);
		}
	}
	
	
	/**
	 * Return the query response as a SimpleXMLElement object
	 * 
	 * @return SimpleXMLElement
	 */
	public function getResponse() {
		return $this->_response;
	}
	
	/**
	 * Return the query response id
	 * 
	 * @return array
	 */
	public function getResponseId() {
		return $this->_responseId;
	}
	
	/**
	 * Return the query response code
	 * 
	 * @return array
	 */
	public function getResponseCode() {
		return $this->_responseCode;
	}
	
	/**
	 * Return the query response status
	 * 
	 * @return string
	 */
	public function getStatus() {
		return $this->_status;
	}
	
	/**
	 * Return the query result as an array
	 * 
	 * @return array
	 */
	public function getResult() {
		return $this->_resultArray;
	}
	
	/**
	 * Convert a multidimentional SimpleXMLElement object to a multidimentional array
	 * This is required as using only the json_decode( json_encode()) trick would flatten a single item array
	 * 
	 * @param SimpleXMLElement $xml
	 * @return array
	 */
	private function convertResultAsArray($xml) {
		$arr = array();

		foreach ($xml->children() as $r) {
			$t = array();
			if (count($r->children()) == 0) {
				$arr[$r->getName()] = strval($r);
			} else {
				$arr[$r->getName()][] = $this->convertResultAsArray($r);
			}
		}
		return $arr;
	}

}