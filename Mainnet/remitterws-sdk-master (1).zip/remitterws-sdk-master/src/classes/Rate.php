<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * Rate class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->rate->methodName();
 */
class Rate extends RemitterWSBaseClass {
	
	protected $path = 'rate';
	
	/**
	 * Retrieve the list of rates available in the system
	 * 
	 * @param array $input All input data with the correct keys (optional)
	 * @return array
	 */
	public function getRates($input=[]) {
		$list = [
			'destination_country',
			'source_currency',
			'destination_currency',
		];
		
		$data = $this->getRequestData($list, $input);
		
		$response = $this->ws->request($this->getPath('getRates'), array_merge([
				'username' => $this->ws->config->getUsername(),
				'session_token' => $this->ws->config->getToken()
			], $data));
		
		return $response->getResult();
	}
	
}