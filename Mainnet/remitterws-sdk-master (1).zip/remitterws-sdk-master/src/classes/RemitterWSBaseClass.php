<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSRestClient;

/**
 * Base class for the RemitONE Remitter Web Services
 */
abstract class RemitterWSBaseClass {
	
	protected $path = null;
	protected $ws = null;
	
	/**
	 * Save the provided RemitterWSRestClient instance
	 *
	 * @param RemitterWSRestClient $ws Instance of the RemitterWSRestClient
	 * @return RemitterWSBaseClass this
	 */
	public function __construct(RemitterWSRestClient $ws) {
		$this->ws = $ws;
	}
	
	/**
	 * Return the path for the specified method
	 *
	 * @param string $method API method
	 * @return string Path of the API method
	 */
	protected function getPath($method) {
		return $this->path.'/'.$method;
	}
	
	/**
	 * Return only the requested data
	 * 
	 * @param array $list
	 * @param array $input
	 * @return array
	 */
	protected function getRequestData($list, $input) {
		return array_intersect_key($input, array_flip($list));
	}
	
}