<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */

namespace RemitONE\RemitterWS\classes;

use RemitONE\RemitterWS\classes\RemitterWSBaseClass;
use RemitONE\RemitterWS\classes\RemitterWSException;

/**
 * UI Settings class for the RemitONE Remitter Web Services
 *
 * This class should not be instantiated directly.
 * Instead, call it through a new instance of RemitterWS such as:
 * $remitterWS = new RemitterWS;
 * $remitterWS->UISettings->methodName();
 */
class UISettings extends RemitterWSBaseClass {
	
	protected $path = 'UISettings';
	
	/**
	 * Retrieve the list of images to display in the carousel
	 * 
	 * @param string $type
	 * @return array
	 */
	public function getCarouselImages($type) {
		$response = $this->ws->request($this->getPath('getCarouselImages'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'type' => $type,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve the list of prefixes for every country
	 * 
	 * @param string $isoCode
	 * @return array
	 */
	public function getCountryPrefixes($isoCode=null) {
		$response = $this->ws->request($this->getPath('getCountryPrefixes'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'iso_code' => $isoCode,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve all fields that need to be displayed as well as which ones are required in order to create/update beneficiaries.
	 * 
	 * @param integer $destination_country_id
	 * @return array
	 */
	public function getBeneficiaryUISettings($destination_country_id) {
		$response = $this->ws->request($this->getPath('getBeneficiaryUISettings'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve all fields that need to be displayed as well as which ones are required in order to register/update a remitter. 
	 * Additionally, the list of nationalities and “hear about us” options are included if needed.
	 * 
	 * @param string $source_country_id
	 * @return array
	 */
	public function getRemitterUISettings($source_country_id) {
		$response = $this->ws->request($this->getPath('getRemitterUISettings'), [
			'source_country_id' => $source_country_id,
		]);
		
		return $response->getResult();
	}
	
	/**
	 * Retrieve all fields that need to be displayed as well as which ones are required in order to create a new transaction. 
	 * This will also include the remittance payment methods, transfer types and other data available.
	 *
	 * @param integer $destination_country_id
	 * @param string $transfer_type (optional)
	 * @param string $account_item_number (optional)
	 * @return array
	 */
	public function getTransactionUISettings($destination_country_id, $transfer_type=null, $account_item_number=1) {
		$response = $this->ws->request($this->getPath('getTransactionUISettings'), [
			'username' => $this->ws->config->getUsername(),
			'session_token' => $this->ws->config->getToken(),
			'destination_country_id' => $destination_country_id,
			'transfer_type' => $transfer_type,
			'account_item_number' => $account_item_number,
		]);
		
		return $response->getResult();
	}
	
}