<?php 
/* Copyright 2005-2017 Remit One Ltd. All rights reserved.
  Please see LICENSE.txt */


/*
 * This file provides an example of requests to perform using the RemitONE Remitter WS SDK
 */

require_once "vendor/autoload.php";
use RemitONE\RemitterWS\RemitterWS;

$remitterWS = new RemitterWS;
$remitterWS->auth->setUsername('user@remitone.com');

// Retrieve a session token if the user has no active session
$token = $remitterWS->auth->login('password');

// Alternatively, you can set the session token directly if you have already stored it
// $remitterWS->auth->setSessionToken('1234567890');

// You can then retrieve all the user's transactions
$transactions = $remitterWS->transaction->listTransactions();
