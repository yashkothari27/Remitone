# RemitONE RemitterWS SDK #

RemitONE WebService for remitters

- Easily and quickly integrate with the RemitONE Online Money Transfer Platform.

## Getting started ##
1. Download sources or add the composer requirement for RemitONE/RemitterWS.
2. Run `composer install`
3. Save the provided public and private keys to allow encryption.
4. Run `cp src/Configuration.php.in src/Configuration.php`
5. Edit src/Configuration.php to set up all the required configuration.
6. Explore the methods and create your own application using them!

## Examples ##

```php
$remitterWS = new RemitterWS;
$remitterWS->auth->setUsername('user@remitone.com');

// Retrieve a session token if the user has no active session
$token = $remitterWS->auth->login('password');

// Alternatively, you can set the session token directly if you have already stored it
$remitterWS->auth->setSessionToken('1234567890');

// You can then retrieve all the user's transactions
$transactions = $remitterWS->transaction->listTransactions();
```

## Support ##
- If you have any issue, please contact our [Support department](http://support.remitone.com).
- For business enquiry, please contact our [Sale department](https://www.remitone.com/request-a-demo/).

### License [(c) Copyright 2005-2017 Remit One Ltd. All rights reserved.](LICENSE)
